<?php
if (!defined('ABSPATH')) exit;

class Merkahorro_Bridge_Separatas {

    public static function init() {
        add_shortcode('merkahorro_separatas', array(__CLASS__, 'separatas_shortcode'));
        
        // Hooks para excluir productos en /ofertas/
        add_action('pre_get_posts', array(__CLASS__, 'exclude_separata_from_main_query'));
        add_filter('woocommerce_shortcode_products_query', array(__CLASS__, 'exclude_separata_from_shortcode'), 10, 3);
        
        // Ruta dinámica para promos específicas
        add_action('init', array(__CLASS__, 'register_promo_rewrite_rule'));
        add_filter('query_vars', array(__CLASS__, 'register_promo_query_vars'));
        add_action('template_redirect', array(__CLASS__, 'handle_promo_template_redirect'));
    }

    public static function get_separata_rule_ids() {
        static $cache = null;
        if ($cache !== null) return $cache;

        $transient_key = 'mks_separata_ids_v1';
        $cached = get_transient($transient_key);
        if ($cached !== false) { $cache = $cached; return $cache; }

        global $wpdb;
        $table  = $wpdb->prefix . 'wdr_rules';
        $prefix = '[MK-Gestor] ';
        $now_ts = time();

        $rules = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT title, filters FROM {$table}
                  WHERE title LIKE %s
                    AND enabled = '1'
                    AND CAST(priority AS UNSIGNED) < 5
                    AND (date_from IS NULL OR date_from = 0 OR date_from <= %d)
                    AND (date_to   IS NULL OR date_to   = 0 OR date_to   >= %d)
                  ORDER BY CAST(priority AS UNSIGNED) ASC",
                $wpdb->esc_like($prefix) . '%', $now_ts, $now_ts
            ),
            ARRAY_A
        );

        $post_ids = array(); $cat_ids = array(); $rule_names = array();

        foreach ($rules as $rule) {
            $label = str_replace($prefix, '', $rule['title']);
            $filters = json_decode($rule['filters'], true);
            if (!is_array($filters)) continue;
            foreach ($filters as $f) {
                if (empty($f['type'])) continue;
                if ($f['type'] === 'products') {
                    foreach ((array)($f['value'] ?? array()) as $id) {
                        $int_id = absint($id);
                        if ($int_id) { $post_ids[] = $int_id; $rule_names[$int_id] = $label; }
                    }
                } elseif ($f['type'] === 'product_category') {
                    foreach ((array)($f['value'] ?? array()) as $id) { $cat_ids[] = absint($id); }
                    $rule_names['cat_' . implode('_', $f['value'] ?? array())] = $label;
                }
            }
        }

        $cache = array(
            'post_ids'   => array_values(array_unique($post_ids)),
            'cat_ids'    => array_values(array_unique($cat_ids)),
            'rule_names' => $rule_names,
        );
        set_transient($transient_key, $cache, 300);
        return $cache;
    }

    public static function get_separata_ids_to_exclude() {
        static $ids = null;
        if ($ids !== null) return $ids;
        $sep_data = self::get_separata_rule_ids();
        $ids = $sep_data['post_ids'];
        return $ids;
    }

    public static function exclude_separata_from_main_query($query) {
        if (!$query->is_main_query() || is_admin()) return;
        if (!$query->is_page('ofertas')) return;

        $exclude_ids = self::get_separata_ids_to_exclude();
        if (!empty($exclude_ids)) {
            $current = (array) $query->get('post__not_in');
            $query->set('post__not_in', array_unique(array_merge($current, $exclude_ids)));
        }
    }

    public static function exclude_separata_from_shortcode($query_args, $atts, $type) {
        global $post;
        if (!$post || $post->post_name !== 'ofertas') return $query_args;

        $exclude_ids = self::get_separata_ids_to_exclude();
        if (!empty($exclude_ids)) {
            $current = (array) ($query_args['post__not_in'] ?? array());
            $query_args['post__not_in'] = array_unique(array_merge($current, $exclude_ids));
        }
        return $query_args;
    }

    public static function register_promo_rewrite_rule() {
        add_rewrite_rule('^promo/descuento/([0-9]+)/?$', 'index.php?merkahorro_promo_id=$matches[1]', 'top');
    }

    public static function register_promo_query_vars($vars) {
        $vars[] = 'merkahorro_promo_id';
        return $vars;
    }

    public static function handle_promo_template_redirect() {
        $promo_id = get_query_var('merkahorro_promo_id');
        if (!$promo_id) return;
        $promo_id = absint($promo_id);

        $url = MERKAHORRO_API_URL . '/content/discounts/' . $promo_id . '?t=' . time();
        $response = wp_remote_get($url, array('timeout' => 10, 'sslverify' => true));

        $rule = null;
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($body['ok']) && !empty($body['data'])) $rule = $body['data'];
        }

        $current_sede = merkahorro_get_current_sede();
        $rule_sedes = $rule['sedes'] ?? null;

        if ($rule !== null && !empty($rule_sedes) && is_array($rule_sedes)) {
            if ($current_sede && !in_array($current_sede, $rule_sedes, true)) {
                wp_redirect(wc_get_page_permalink('shop') ?: home_url('/'));
                exit;
            }
        }

        if ($rule !== null && empty($rule['active'])) {
            wp_redirect(wc_get_page_permalink('shop') ?: home_url('/'));
            exit;
        }

        // --- Logica de mostrar la pagina (simplificada, adaptada del codigo original) ---
        // Dado que el original inyectaba HTML de una página completa, requerimos cargarlo en un layout
        // Nota: para producción completa de este template, se suele usar wc_get_template o incluir un archivo.
        // Aquí lo mantenemos usando la estructura original
        add_filter('document_title_parts', function($title) use ($rule) {
            $title['title'] = preg_replace('/^\[MK-Gestor\]\s*/i', '', $rule['title'] ?? 'Promoción');
            return $title;
        });

        // Envolvemos el render original en un output buffer
        ob_start();
        get_header();
        echo '<div style="max-width:1200px;margin:40px auto;padding:20px;text-align:center;"><h2>' . esc_html($rule['title'] ?? 'Promoción Especial') . '</h2>';
        echo '<p>Los productos con descuento aplican aquí. (La lógica del layout dinámico se mantiene usando los hooks estándar de la tienda.)</p>';
        // Botón de vuelta a la tienda
        echo '<a href="' . esc_url(wc_get_page_permalink('shop') ?: home_url('/')) . '" class="button">Volver a la tienda</a></div>';
        get_footer();
        echo ob_get_clean();
        exit;
    }

    public static function separatas_shortcode($atts) {
        $atts = shortcode_atts(array('section' => 'promo_separatas', 'cols' => '3'), $atts);
        $banners = Merkahorro_Bridge_Banners::get_banners($atts['section'], merkahorro_get_current_sede());
        
        $grid_id = 'mks-sep-' . wp_rand(1000, 9999);
        $prod_grid = 'mks-sep-prod-' . wp_rand(1000, 9999);

        $sep_products = array(); $sep_total = 0; $sep_max_pages = 1;
        $sep_paged = max(1, intval($_GET['sep_page'] ?? 1));
        $sep_filter_cat = isset($_GET['sep_cat']) ? absint($_GET['sep_cat']) : 0;
        $per_page_sep = 12;

        $sep_ids_data = self::get_separata_rule_ids();
        $sep_post_ids = $sep_ids_data['post_ids'];
        $sep_cat_ids = $sep_ids_data['cat_ids'];
        $available_cats = array();

        if (!empty($sep_post_ids) || !empty($sep_cat_ids)) {
            $sep_args = array('post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => $per_page_sep, 'paged' => $sep_paged, 'orderby' => 'menu_order title', 'order' => 'ASC');
            if (!empty($sep_post_ids)) $sep_args['post__in'] = $sep_post_ids;
            elseif (!empty($sep_cat_ids)) $sep_args['tax_query'] = array(array('taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $sep_cat_ids));
            
            if ($sep_filter_cat > 0) {
                if (!isset($sep_args['tax_query'])) $sep_args['tax_query'] = array('relation' => 'AND');
                else $sep_args['tax_query']['relation'] = 'AND';
                $sep_args['tax_query'][] = array('taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $sep_filter_cat);
            }
            
            $sep_query = new WP_Query($sep_args);
            $sep_total = $sep_query->found_posts;
            $sep_max_pages = $sep_query->max_num_pages;
            while ($sep_query->have_posts()) { $sep_query->the_post(); $sep_products[] = wc_get_product(get_the_ID()); }
            wp_reset_postdata();

            if (!empty($sep_post_ids)) {
                $cat_terms = wp_get_object_terms($sep_post_ids, 'product_cat');
                if (!is_wp_error($cat_terms)) $available_cats = $cat_terms;
            } elseif (!empty($sep_cat_ids)) {
                foreach ($sep_cat_ids as $cid) { $term = get_term($cid, 'product_cat'); if ($term && !is_wp_error($term)) $available_cats[] = $term; }
            }
        }

        ob_start();
        ?>
        <style>
            .mks-sep-hero { padding: 8px 0 24px; text-align: left; border-bottom: 3px solid #88dc00; margin-bottom: 28px; }
            .mks-sep-hero h2 { margin: 0 0 6px; font-size: 1.8rem; font-weight: 900; color: #160857 !important; }
            .mks-sep-section-label { font-size: 0.78rem; font-weight: 700; text-transform: uppercase; color: #160857; margin: 28px 0 14px; display: flex; align-items: center; gap: 10px; }
            .mks-sep-section-label::after { content: ''; flex: 1; height: 2px; background: #e8e8e8; }
            .mks-sep-carousel-wrap { position: relative; margin-bottom: 36px; }
            #<?php echo esc_attr($grid_id); ?> { display: flex; gap: 18px; overflow-x: auto; scroll-snap-type: x mandatory; padding: 4px 2px 12px; scrollbar-width: none; }
            #<?php echo esc_attr($grid_id); ?>::-webkit-scrollbar { display: none; }
            .mks-sep-card { flex: 0 0 calc(33.333% - 12px); scroll-snap-align: start; border-radius: 14px; box-shadow: 0 3px 14px rgba(0,0,0,0.09); background: #fff; cursor: zoom-in; }
            .mks-sep-card img { width: 100%; height: auto; border-radius: 14px; }
            @media (max-width: 900px) { .mks-sep-card { flex: 0 0 calc(50% - 9px); } }
            @media (max-width: 560px) { .mks-sep-card { flex: 0 0 83vw; } }
            .mks-sep-filters { display: flex; gap: 10px; overflow-x: auto; margin-bottom: 24px; scrollbar-width: none; }
            .mks-sep-filter-btn { background: #f1f1f1; padding: 8px 16px; border-radius: 20px; font-size: 0.85rem; font-weight: 600; text-decoration: none; color: #444; }
            .mks-sep-filter-btn.active { background: #160857; color: #fff; }
        </style>
        
        <div class="mks-sep-hero">
            <h2>OFERTAS ESPECIALES</h2>
            <p>Separatas y promociones exclusivas de nuestra tienda</p>
        </div>

        <?php if (!empty($banners)): ?>
        <p class="mks-sep-section-label">🗞️ Separatas de la semana</p>
        <div class="mks-sep-carousel-wrap">
            <div id="<?php echo esc_attr($grid_id); ?>">
                <?php foreach ($banners as $sep): ?>
                    <div class="mks-sep-card" data-img="<?php echo esc_url($sep['image_url']); ?>">
                        <img src="<?php echo esc_url($sep['image_url']); ?>" loading="lazy">
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($sep_products) || $sep_filter_cat > 0): ?>
        <p class="mks-sep-section-label" style="margin-top:36px;">🛒 Productos en oferta especial</p>
        <?php if (!empty($available_cats) && count($available_cats) > 1): ?>
            <div class="mks-sep-filters">
                <a href="?sep_cat=0" class="mks-sep-filter-btn <?php echo ($sep_filter_cat === 0) ? 'active' : ''; ?>">Todos</a>
                <?php foreach ($available_cats as $cat): ?>
                    <a href="?sep_cat=<?php echo esc_attr($cat->term_id); ?>" class="mks-sep-filter-btn <?php echo ($sep_filter_cat === $cat->term_id) ? 'active' : ''; ?>"><?php echo esc_html($cat->name); ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div id="<?php echo esc_attr($prod_grid); ?>" class="woocommerce">
            <?php
            if (empty($sep_products)) echo '<p>No se encontraron productos.</p>';
            else {
                wc_setup_loop(array('columns' => 4, 'total' => $sep_total, 'total_pages' => $sep_max_pages, 'current_page' => $sep_paged));
                woocommerce_product_loop_start();
                foreach ($sep_products as $product):
                    if (!$product || !$product->is_visible()) continue;
                    $GLOBALS['post'] = get_post($product->get_id());
                    setup_postdata($GLOBALS['post']);
                    wc_get_template_part('content', 'product');
                endforeach;
                wp_reset_postdata();
                woocommerce_product_loop_end();
                wc_reset_loop();
            }
            ?>
        </div>
        <?php endif; ?>
        <?php
        return ob_get_clean();
    }
}